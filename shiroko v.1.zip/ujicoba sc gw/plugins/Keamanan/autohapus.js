let messageTimestamps = {};

let handler = async (m, { conn }) => {
    messageTimestamps[m.key.id] = new Date().getTime();
    checkAndDeleteMessages(conn);
};

let checkAndDeleteMessages = async (conn) => {
    let now = new Date().getTime();
    for (let msgId in messageTimestamps) {
        let timestamp = messageTimestamps[msgId];
        if (now - timestamp > 300000) {
            try {
                let msg = await conn.loadMessage(msgId);
                if (msg) {
                    await conn.deleteMessage(msg.chat, msg.key);
                    delete messageTimestamps[msgId];
                }
            } catch (err) {
                console.log(err);
            }
        }
    }
};

setInterval(() => {
    checkAndDeleteMessages(global.conn);
}, 60000);

module.exports = handler;