let toxicWords = ["kontol", "Kontol", "goblok"," tolol","yatim","asu","pantat"]; // Masukkan kata-kata toxic yang dilarang
let handler = async (m, { isAdmin, isBotAdmin, groupMetadata }) => {
    if (!m.isGroup) return; // Fitur hanya untuk grup

    let isViolation = false; // Status pelanggaran
    let reason = ""; // Alasan pelanggaran

    // Cek link
    if (m.text && m.text.match(/(https?:\/\/[^\s]+)/gi)) {
        isViolation = true;
        reason = "mengirimkan link";
    }

    // Cek video
    if (m.message?.videoMessage) {
        isViolation = true;
        reason = "mengirimkan video";
    }

    // Cek kata kasar
    if (m.text && toxicWords.some((word) => m.text.toLowerCase().includes(word))) {
        isViolation = true;
        reason = "menggunakan kata-kata kasar";
    }

    // Jika ada pelanggaran
    if (isViolation) {
        if (!isBotAdmin) return m.reply("⚠️ @shino bukan admin, tidak bisa menendang pengguna!");
        if (isAdmin) return m.reply("⚠️ Pengguna adalah admin, tidak bisa ditendang!");

        let user = m.sender;
        await m.reply(`⚠️ *Peringatan!*\nPengguna @${user.split("@")[0]} melanggar aturan grup karena ${reason}.\n\nPengguna akan dikeluarkan dari grup!`, {
            mentions: [user],
        });

        // Kick pengguna
        await this.groupParticipantsUpdate(m.chat, [user], "remove");
    }
};

// Informasi tentang command
handler.help = ["antilink", "antivideo", "antitoxic"];
handler.tags = ["admin", "group"];
handler.command = /^(antilink|antivideo|antitoxic)$/i; // Tidak perlu perintah, otomatis berjalan

module.exports = handler;