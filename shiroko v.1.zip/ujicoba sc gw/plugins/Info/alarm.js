const schedule = require('node-schedule'); // Pastikan Anda telah menginstal library ini

let handler = async (m, { conn }) => {};

// Konfigurasi alarm
const alarms = [
    {
        time: '3 0 * * *', // Waktu dalam format cron (Jam 3 pagi setiap hari)
        audioPath: './media/alarm.mp3', // Path ke file audio
        chatId: 'YOUR_CHAT_ID' // ID Grup atau Chat yang ingin dikirim
    },
    // Tambahkan alarm lain jika diperlukan
];

// Fungsi untuk mengatur alarm
const setupAlarms = (conn) => {
    alarms.forEach((alarm) => {
        schedule.scheduleJob(alarm.time, async () => {
            try {
                // Kirim audio ke chat yang ditentukan
                await conn.sendFile(alarm.chatId, alarm.audioPath, 'alarm.mp3', null, { ptt: true });
                console.log(`Alarm dikirim ke ${alarm.chatId} pada ${new Date().toLocaleString()}`);
            } catch (err) {
                console.error(`Gagal mengirim alarm: ${err.message}`);
            }
        });
    });
};

// Memastikan fungsi ini dipanggil ketika bot di-load
handler.onLoad = (conn) => setupAlarms(conn);

handler.help = ['alarm'];
handler.tags = ['tools'];
handler.command = ['alarm'];

module.exports = handler;