const moment = require('moment-timezone'); // Library untuk menangani waktu
const { isBotAdmin, isAdmin } = require('./utils'); // Utility untuk memeriksa admin

let handler = async (m, { conn }) => {
    // Mendapatkan waktu saat ini di zona waktu yang sesuai (misalnya: Waktu Indonesia Barat)
    const now = moment().tz('Asia/Jakarta').format('HH:mm');
    
    // Memeriksa apakah waktu sekarang adalah 05:00 pagi
    if (now === '05:00') {
        // Jika bot adalah admin grup, buka grup (ubah menjadi mode terbuka)
        if (await isBotAdmin(m.chat)) {
            await conn.groupSettingUpdate(m.chat, 'not_announcement'); // Mengubah grup menjadi tidak terkunci
            m.reply('Grup telah dibuka otomatis pada jam 5 pagi!');
        } else {
            m.reply('Saya bukan admin grup, jadi saya tidak bisa membuka grup.');
        }
    }
};

// Fungsi untuk menjadwalkan plugin ini berjalan setiap menit
const scheduleOpening = () => {
    setInterval(async () => {
        // Mendapatkan waktu sekarang dalam format 24 jam
        const now = moment().tz('Asia/Jakarta').format('HH:mm');
        
        // Cek apakah waktu adalah jam 5 pagi
        if (now === '05:00') {
            console.log("Menjalankan plugin buka grup otomatis pada jam 5 pagi...");
            // Menjalankan perintah buka grup
            handler({ chat: "group-chat-id" }, { conn: global.conn });
        }
    }, 60000); // Cek setiap menit
};

// Memulai penjadwalan ketika bot mulai aktif
scheduleOpening();

module.exports = handler;