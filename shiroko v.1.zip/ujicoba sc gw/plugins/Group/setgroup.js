let targetGroup = ""; // ID grup tujuan, format: "1234567890-123456@g.us"
let isUploadMode = false; // Status mode upload

let handler = async (m, { text, isGroup, isAdmin }) => {
    if (!isGroup) return; // Fitur hanya bisa digunakan di grup

    // Perintah untuk mengaktifkan upload mode
    if (m.text === ".upgc") {
        if (!isAdmin) return m.reply("⚠️ Perintah ini hanya dapat digunakan oleh admin!");
        if (!targetGroup) return m.reply("⚠️ Grup tujuan belum diset. Silakan set grup tujuan dengan perintah `.setgroup <group_id>`.");

        isUploadMode = !isUploadMode; // Toggle mode upload
        let status = isUploadMode ? "aktif" : "nonaktif";
        return m.reply(`✅ Mode upload grup ${status}. Semua pesan sekarang akan dikirim ke grup tujuan.`);
    }

    // Perintah untuk mengatur grup tujuan
    if (m.text.startsWith(".setgroup")) {
        if (!isAdmin) return m.reply("⚠️ Perintah ini hanya dapat digunakan oleh admin!");
        let args = text.split(" ");
        if (args.length < 2) return m.reply("⚠️ Format salah. Gunakan: `.setgroup <group_id>`");

        targetGroup = args[1];
        return m.reply(`✅ Grup tujuan telah diset ke: ${targetGroup}`);
    }

    // Mode upload aktif: kirim semua pesan ke grup tujuan
    if (isUploadMode && targetGroup) {
        try {
            await this.sendMessage(targetGroup, { text: m.text }, { quoted: m });
        } catch (err) {
            console.error(err);
            return m.reply("⚠️ Gagal mengirim pesan ke grup tujuan.");
        }
    }
};

// Informasi tentang command
handler.help = [".upgc", ".setgrup"];
handler.tags = ["admin", "group"];
handler.command = /^(upgc|setgrup)$/i; // Perintah untuk mode dan set grup

module.exports = handler;