let handler = async (m, { text }) => {
    // Mengirimkan pesan format absen kepada anggota grup
    let responseMessage = `📋 **Absensi Grup** 📋

    **Silakan isi informasi berikut:**
    
    1. **Nama**:
    2. **Kelas**:
    3. **Umur**:
    4. **Tempat Tinggal**:
    5. **Tanggal Lahir (DD/MM/YYYY)**:
    6. **Tempat Lahir**:
    7. **Penghasilan Bulanan**:
    8. **Status Pekerjaan** (Jika ada):
    9. **Hobi**:
    10. **Kegiatan/Organisasi yang diikuti** (Jika ada):
    11. **Keinginan atau Harapan**:

    📌 *Pastikan Anda mengisi data dengan benar!* 📌
    
    🕒 *Waktu absensi ini hanya berlaku hingga tanggal (5 menit).* 🕒

    Jangan lupa untuk menanggapi pesan ini dengan lengkap agar absen Anda tercatat.`;

    // Mengirimkan pesan ke grup atau ke pengguna yang meminta
    m.reply(responseMessage);
};

handler.help = ["alpa"];
handler.tags = ["group"];
handler.command = ["alpa"];

module.exports = handler;