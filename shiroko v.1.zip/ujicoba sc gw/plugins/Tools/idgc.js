let handler = async (m, { conn, isGroup, isAdmin, isOwner }) => {
    // Pastikan perintah dijalankan di dalam grup
    if (!isGroup) return conn.reply(m.chat, 'Perintah ini hanya bisa digunakan di dalam grup!', m);

    // Pastikan hanya admin grup atau pemilik bot yang dapat menggunakan perintah ini
    if (!isAdmin && !isOwner) return conn.reply(m.chat, 'Perintah ini hanya untuk admin grup atau pemilik bot.', m);

    try {
        const groupId = m.chat; // Mengambil ID grup dari chat
        conn.reply(m.chat, `ID Grup ini adalah:\n\n${groupId}`, m);
    } catch (err) {
        console.error(err);
        conn.reply(m.chat, 'Terjadi kesalahan saat mengambil ID grup.', m);
    }
};

handler.help = ['idgrup'];
handler.tags = ['tools'];
handler.command = ['idgc','idgroup'];

module.exports = handler;