let handler = async (m, { conn, args, isAdmin, isOwner }) => {
    // Pastikan hanya admin atau pemilik bot yang dapat menggunakan plugin ini
    if (!isAdmin && !isOwner) return conn.reply(m.chat, 'Perintah ini hanya untuk admin atau pemilik bot.', m);

    if (args.length < 2) {
        return conn.reply(
            m.chat,
            'Format salah! Gunakan format berikut:\n\n!kirimgrup <chat_id> <path_file> [nama_file_optional]\n\nContoh:\n!kirimgrup 123456789@g.us ./media/contoh.pdf',
            m
        );
    }

    const chatId = args[0]; // ID grup tempat file dikirim
    const filePath = args[1]; // Path file yang diberikan oleh pengguna
    const fileName = args[2] || filePath.split('/').pop(); // Nama file default diambil dari path jika tidak diberikan

    try {
        // Kirim file ke grup yang ditentukan
        await conn.sendFile(chatId, filePath, fileName, `Berikut file "${fileName}" yang diminta.`, null);
        conn.reply(m.chat, `File "${fileName}" berhasil dikirim ke grup ${chatId}.`, m);
    } catch (err) {
        console.error(err);
        conn.reply(
            m.chat,
            `Gagal mengirim file. Pastikan file tersedia di path "${filePath}" dan bot memiliki akses ke grup ${chatId}.`,
            m
        );
    }
};

handler.help = ['togc'];
handler.tags = ['tools'];
handler.command = ['togc'];

module.exports = handler;