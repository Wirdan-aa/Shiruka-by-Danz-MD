let handler = async (m, { text }) => {
    const response = `
📌 *Tata Cara Mandi Wajib (Mandi Junub):*

1. *Niat*: Bacalah niat mandi wajib dalam hati. Contohnya:
   _Nawaitul ghusla liraf'il hadatsil akbari fardhal lillaahi ta'aala_.

2. *Membersihkan Kotoran*:
   - Bersihkan kedua tangan.
   - Bersihkan kemaluan dan kotoran dengan tangan kiri.

3. *Berwudhu*:
   - Lakukan wudhu seperti biasa sebelum mandi.

4. *Meratakan Air ke Seluruh Tubuh*:
   - Mulailah dari kepala, basahi seluruh rambut hingga kulit kepala.
   - Ratakan air ke seluruh tubuh, mulai dari sisi kanan lalu kiri.
   - Pastikan tidak ada bagian tubuh yang kering, termasuk sela-sela jari, rambut, lipatan tubuh, dan kuku.

🌟 Semoga bermanfaat dan ibadah Anda diterima oleh Allah SWT!
    `;

    m.reply(response);
};

// Informasi tentang command
handler.help = ["mandiwajib"];
handler.tags = ["islam"];
handler.command = ["mandi", "mandijunub", "tatacaramandiwajib"];

module.exports = handler;