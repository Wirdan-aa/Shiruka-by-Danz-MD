let handler = async (m, { text }) => {
    // Tanggal Ramadan berikutnya (ganti sesuai tahun)
    let ramadhanDate = new Date("2024-03-28:00:00"); // Format: YYYY-MM-DD
    let now = new Date();
    
    // Hitung selisih waktu
    let diff = ramadhanDate - now;
    
    if (diff <= 0) {
        m.reply("Ramadan telah tiba! Selamat menunaikan ibadah puasa.");
        return;
    }

    // Hitung hari, jam, menit, dan detik
    let days = Math.floor(diff / (1000 * 60 * 60 * 24));
    let hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((diff % (1000 * 60)) / 1000);

    // Buat pesan hitung mundur
    let countdownMessage = `⏳ Hitung Mundur Ramadan ⏳\n` +
        `Tersisa ${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik lagi menuju Ramadan 1445 H.`;

    m.reply(countdownMessage);
};

handler.help = ["hitung"];
handler.tags = ["tools"];
handler.command = ["hitung", "kapanramadhan"];

module.exports = handler;