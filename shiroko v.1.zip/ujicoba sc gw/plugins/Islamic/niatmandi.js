let handler = async (m) => {
    const response = `
📌 *Niat Mandi Wajib (Mandi Junub)*:

_Bahasa Arab:_
نَوَيْتُ الْغُسْلَ لِرَفْعِ الْحَدَثِ الْأَكْبَرِ فَرْضًا لِلّٰهِ تَعَالٰى

_Bahasa Latin:_
Nawaitul ghusla liraf'il hadatsil akbari fardhan lillaahi ta'aala.

_Artinya:_
"Saya niat mandi untuk menghilangkan hadas besar, fardu karena Allah Ta'ala."

Semoga niat dan ibadah Anda diterima. 🌟
    `;

    m.reply(response);
};

// Informasi tentang command
handler.help = ["niatmandiwajib"];
handler.tags = ["islam"];
handler.command = ["niatmandi", "niatmandijunub", "niatjunub"];

module.exports = handler;