let handler = async (m, { conn, command }) => {
    const niatSunnah = {
        dhuha: `NIAT SHOLAT DHUHA
        Arab: 
        أُصَلِّيْ سُنَّةَ الضُّحَى رَكْعَتَيْنِ لِلَّهِ تَعَالَى
        Latin: 
        Ushalli sunnatad-dhuhaa rak‘ataini lillaahi ta‘aalaa.
        Artinya:
        Aku niat sholat sunnah dhuha dua rakaat karena Allah Ta’ala.`,

        tahajjud: `NIAT SHOLAT TAHAJJUD
        Arab: 
        أُصَلِّيْ سُنَّةَ التَهَجُّدِ رَكْعَتَيْنِ لِلَّهِ تَعَالَى
        Latin: 
        Ushalli sunnat tahajjudi rak‘ataini lillaahi ta‘aalaa.
        Artinya:
        Aku niat sholat sunnah tahajjud dua rakaat karena Allah Ta’ala.`,

        witir: `NIAT SHOLAT WITIR
        Arab: 
        أُصَلِّيْ سُنَّةَ الْوِتْرِ رَكْعَةً لِلَّهِ تَعَالَى
        Latin: 
        Ushalli sunnatal-witri rak‘atan lillaahi ta‘aalaa.
        Artinya:
        Aku niat sholat sunnah witir satu rakaat karena Allah Ta’ala.`,
    };

    // Kirim niat berdasarkan perintah
    let text = niatSunnah[command];
    if (!text) return conn.reply(m.chat, 'Pilihan sholat sunnah: dhuha, tahajjud, witir', m);

    conn.reply(m.chat, text, m);
};

handler.help = ['dhuha', 'tahajjud', 'witir'];
handler.tags = ['ibadah'];
handler.command = ['dhuha', 'tahajjud', 'witir']; // Menggunakan nama perintah untuk jenis sholat

module.exports = handler;