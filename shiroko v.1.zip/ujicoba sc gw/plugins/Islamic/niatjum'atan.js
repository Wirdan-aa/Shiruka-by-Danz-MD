let handler = async (m, { conn }) => {
    const niatJumat = `NIAT SHOLAT JUM'AT
    Arab: 
    أُصَلِّيْ فَرْضَ الْجُمُعَةِ رَكْعَتَيْنِ مَأْمُوْمًا لِلَّهِ تَعَالَى
    Latin: 
    Ushalli fardhal-jumu‘ati rak‘ataini ma’muuman lillaahi ta‘aalaa.
    Artinya:
    Aku niat sholat fardhu Jum’at dua rakaat (sebagai makmum) karena Allah Ta’ala.`;

    conn.reply(m.chat, niatJumat, m);
};

handler.help = ['jumat'];
handler.tags = ['ibadah'];
handler.command = ['jumat'];

module.exports = handler;