/* 
  ────────「 *RANGELOFFICIAL* 」──────── 
  Powered by *EhanzDhoanx* × *MENHERA MD* 
  Copyright © Raihan Fadillah 
  Instagram: @ehanzdhonax 

  ⚠️ *Jangan hapus watermark ini!* 
  Dukunganmu sangat berarti untuk kami! 
  ──────────────────────────────── 
*/

const fetch = require('node-fetch');

let handler = async (m, { hanz, text }) => {
  if (!text) return m.reply('Silakan masukkan tautan YouTube yang ingin diunduh.');

  try {
    // Mengakses API
    const response = await fetch(`https://api.agatz.xyz/api/ytmp4?url=${encodeURIComponent(text)}`);
    const json = await response.json();

    if (json.status !== 200) throw new Error("Gagal mengambil data video.");
    const videoData = json.data;

    // Mencari kualitas 480p
    const selectedVideo = videoData.find(item => item.quality === "480p");

    // Jika kualitas 480p tersedia
    if (selectedVideo) {
      const caption = `📹 *Judul:* ${json.data.title}\n🎞️ *Kualitas:* ${selectedVideo.quality}\n\nSedang mengirim video...`;

      // Mengirim video
      await hanz.sendMessage(m.chat, { video: { url: selectedVideo.media }, caption: caption }, { quoted: m });
    } else {
      m.reply("Kualitas 480p tidak tersedia. Silakan coba kualitas lainnya.");
    }
  } catch (error) {
    console.error(error);
    m.reply("Maaf, terjadi kesalahan dalam mengambil video.");
  }
};

handler.command = ['ytmp4'];
handler.tags = ['downloader'];
handler.help = ['ytmp4 <url>'];
handler.limit = true;

module.exports = handler;

     
    

