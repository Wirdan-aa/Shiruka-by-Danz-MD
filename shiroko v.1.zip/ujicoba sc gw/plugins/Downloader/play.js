let yts = require('yt-search'); // Pastikan Anda telah menginstal modul ini: npm install yt-search
let { yta, ytv } = require('../lib/y2mate'); // Pastikan Anda memiliki skrip downloader

let handler = async (m, { conn, text, args }) => {
    if (!text) return conn.reply(m.chat, 'Harap masukkan judul lagu atau kata kunci.\n\nContoh: !play lathi', m);

    try {
        // Cari video berdasarkan kata kunci
        let search = await yts(text);
        let video = search.videos[0];
        if (!video) return conn.reply(m.chat, 'Video tidak ditemukan.', m);

        // Kirim detail video
        let { title, url, timestamp, views, ago } = video;
        let message = `*Judul:* ${title}\n*Durasi:* ${timestamp}\n*Dilihat:* ${views}\n*Diupload:* ${ago}\n\n_Sedang mendownload..._`;
        conn.reply(m.chat, message, m);

        // Pilih format audio atau video
        let isAudio = /audio|musik|lagu/i.test(args[1] || ''); // Default ke audio
        let download = isAudio ? await yta(url) : await ytv(url);

        let { dl_link, filesizeF } = download;
        if (!dl_link) return conn.reply(m.chat, 'Gagal mendapatkan link download.', m);

        // Kirim file ke pengguna
        let caption = `*Judul:* ${title}\n*Ukuran:* ${filesizeF}`;
        await conn.sendFile(m.chat, dl_link, `${title}.${isAudio ? 'mp3' : 'mp4'}`, caption, m);
    } catch (err) {
        console.error(err);
        conn.reply(m.chat, 'Terjadi kesalahan saat memproses permintaan Anda.', m);
    }
};

handler.help = ['play'];
handler.tags = ['downloader'];
handler.command = ['play', 'lagu', 'musik']; // Nama perintah

module.exports = handler;