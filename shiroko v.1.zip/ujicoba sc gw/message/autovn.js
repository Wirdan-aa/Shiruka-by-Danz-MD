//.VN MILIK NINA KAWAI AHH YMATE KUDASAI

//KETIKA ADA YANG TOXIC
exports.vnToxic = [
"./temp/audio/dosa pantek.mp3",
"./temp/audio/heeh.mp3",
"./temp/audio/jangan toxic om.mp3"
]
exports.vnMenu = [
"./temp/audio/dj 1.mp3",
"./temp/audio/dj 2.mp3",
"./temp/audio/dj 3.mp3"
]
exports.vnOwner = [ 
"./temp/audio/ga da.mp3",
"./temp/audio/ga boleh.mp3",
"./temp/audio/ga mau.mp3"
]
exports.vnAra = [ 
"./temp/audio/ara ara goblok.mp3",
"./temp/audio/ara ara.mp3"
    ]
exports.vnBot = [ 
"./temp/audio/ada apa kak.mp3",
"./temp/audio/iya kak.mp3",
"./temp/audio/kenapa kak.mp3",
"./temp/audio/oyy.mp3",
"./temp/audio/ngomong apaan sih.mp3",
"./temp/audio/lu siapa anjir.mp3"
    ]
exports.vnSalam = [ "./temp/audio/walaikunsalam.mp3"]
exports.vnSpam = [ "./temp/audio/jangan spam ntar gua ewe.mp3"]
exports.vnPagi = [ "./temp/audio/pagi.mp3"]
exports.vnSiang = [ 
"./temp/audio/siang.mp3" ]
exports.vnMalam = [ 
 "./temp/audio/malam.mp3"]


exports.vnKawai = [ "https://cdn.filestackcontent.com/zHMFviWeT6eDOvu3eJe3"]
exports.vnLove = [ 
"./temp/audio/lopyu1.mp3",
"./temp/audio/lopyu2.mp3"           ]