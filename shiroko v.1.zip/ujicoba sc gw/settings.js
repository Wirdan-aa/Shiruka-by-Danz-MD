const version = require("baileys/package.json").version
global.language = "id"
const stringSimilarity = require("string-similarity");

//connecting 
global.sessionName = "session"
global.pairingCode = true // true / false
global.pairingNumber = "6282179230256" // masukin nomor bot
global.runWith = "pterodactyl"

//owner
global.ownerName = "@shiroko"
global.nomerOwner = ["6282179230256"]
global.ownerNumber = "6282179230256@s.whatsapp.net"
//sosmed
global.syt = 'https://www.youtube.com/@rangelbot'
global.sgc = 'https://chat.whatsapp.com/EcaZKuqXYGk8DL35OUCetp'
global.sig = 'https://instagram.com/ehanzdhoanx'
global.stt = 'https://www.tiktok.com/@ehanzdhoanx'
global.sgh = 'https://github.com/Rangelofficial'
global.web = 'https://rangelofficial.github.io/webprofile/'
//setbot
global.botName = "@shiroko ᶜᴶˢ"
global.nameToko = "© officialDan"
global.wm = "© officialDanz "
global.setmenu = "button" 

global.newsletterJid = "120363185390263663@newsletter"
global.newsletterJid1 = "120363185390263663@newsletter"
global.newsletterName = "@shiroko ヅ"
global.autoDetectCmd = false;
global.public = false
global.multi = true
global.baileysMd = true
global.antiSpam = true
global.maxwarn = '3' // Peringatan maksimum
//global.prefa = "."
global.fake = botName
global.Console = true
global.session = "session" 
global.autorespon = true
global.copyright = `Bot WhatsApp`
global.baileysVersion = `Baileys ${version}`
global.On = "On"
global.Off ="Off"
global.autoblockcmd = false
global.fake1 ="Bot WhatsApp"
global.packName = `@shiroko`
global.authorName = ""
global.replyType = "web"
global.setwelcome = "type1"
global.autoReport = true
global.autoLevel = true
global.autoSticker = false
global.autoBio = false
global.autoRead = true
global.gamewaktu = 60
global.limitCount = 30
global.Intervalmsg = 1000 //detik
//hiasan
global.gris = '`' // Jangan di ubah
global.gris1 = '```'
global.fileStackApi ="AVKHbeyXsT0G9IKI01qenz" //daftar di filestack
//Toko Online 
global.fotoPakaian = [ 
"https://telegra.ph/file/a2df78368a21a3efc9f34.jpg",
"https://telegra.ph/file/7583097174a260eeffcaf.jpg"]
global.fotoHijab = [""]
global.fotoDistro = [""]
global.fotoRandom = [
"https://pomf2.lain.la/f/fm7dfpvc.jpg",
"https://pomf2.lain.la/f/c4lkd8op.jpg",
"https://telegra.ph/file/a082fe4601ca3216b032c.jpg"
]

//Apikey Nya
global.skizo = 'Rangelofficial'
global.Betabotz = 'LSd7Lq9S'
global.Lolhuman = 'GataDios',
global.FilestackApi = 'AVKHbeyXsT0G9IKI01qenz'
global.Apiflash = "9b9e84dfc18746d4a19d3afe109e9ea4"; 
global.apiTermai = 'AIzaAcWNEZSZep6rdvgv'

// cpanel ======//
global.domain = 'https://panelehanz.my.id.com'
global.apiPlta = '' // Isi Apikey Plta Lu
global.apiPltc = '' // Isi Apikey Pltc Lu 
global.eggs = '15' // id eggs yang dipakai kalo id nya 5 biarin aja ini jangan di ubah
global.location = '1' // id location
//Top up payment 
global.payment = {
    dana: {
      nomer: "082179230256",
      atas_nama: "@shiroko"
    }
} // isi nomor dana lu
global.untung = "1"
  //Ini profit yg kamu dapat, 1 = 1% maka harga akan meningkat 1%
global.apikeyAtlantic = "" //
global.gcounti = {
'prem' : 1000,
'user' : 5
} 
 
global.multiplier = 38
//*========== HIASAN ===========*/

/*============== EMOJI ==============*/
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    let emot = {
      level: "📊",
      limit: "🎫",
      health: "❤️",
      stamina: "⚡",
      exp: "✨",
      atm: "💳",
      money: "💰",
      bank: "🏦",
      potion: "🥤",
      diamond: "💎",
      rawdiamond: "💠",
      common: "📦",
      uncommon: "🛍️",
      mythic: "🎁",
      legendary: "🗃️",
      superior: "💼",
      pet: "🔖",
      trash: "🗑",
      armor: "🥼",
      sword: "⚔️",
      pickaxe: "⛏️",
      axe: "🪓",
      fishingrod: "🎣",
      kondom: "🎴",
      coal: "⬛",
      wood: "🪵",
      rock: "🪨",
      string: "🕸️",
      horse: "🐴",
      cat: "🐱",
      dog: "🐶",
      fox: "🦊",
      robo: "🤖",
      dragon: "🐉",
      petfood: "🍖",
      iron: "⛓️",
      rawiron: "◽",
      gold: "🪙",
      rawgold: "🔸",
      emerald: "❇️",
      upgrader: "🧰",
      bibitanggur: "🌱",
      bibitjeruk: "🌿",
      bibitapel: "☘️",
      bibitmangga: "🍀",
      bibitpisang: "🌴",
      anggur: "🍇",
      jeruk: "🍊",
      apel: "🍎",
      mangga: "🥭",
      pisang: "🍌",
      botol: "🍾",
      kardus: "📦",
      kaleng: "🏮",
      plastik: "📜",
      gelas: "🧋",
      chip: "♋",
      umpan: "🪱",
      skata: "🧩",
      defense: "🛡️",
      strength: "💪🏻",
      speed: "🏃",
      tbox: "🗄️",
    };
      
      
    let results = Object.keys(emot)
      .map((v) => [v, new RegExp(v, "gi")])
      .filter((v) => v[1].test(string));
    if (!results.length) return "";
    else return emot[results[0][0]];
  },
};

function clockString(ms) {
        let months = isNaN(ms) ? "--" : Math.floor(ms / (86400000 * 30.44));
        let d = isNaN(ms) ? "--" : Math.floor(ms / 86400000);
        let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000) % 24;
        let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
        let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
        let monthsDisplay = months > 0 ? months + " bulan, " : "";
        let dDisplay = d > 0 ? d + " hari, " : "";
        let hDisplay = h > 0 ? h + " jam, " : "";
        let mDisplay = m > 0 ? m + " menit, " : "";
        let sDisplay = s > 0 ? s + " detik" : "";
        let time = months > 0 ? monthsDisplay + dDisplay : d > 0 ? dDisplay + hDisplay : h > 0 ? hDisplay + mDisplay  : mDisplay + sDisplay
      
        return time;
      }
let d = new Date();
      let locale = "id";
      let gmt = new Date(0).getTime() - new Date("1 Januari 2021").getTime();
      let week = d.toLocaleDateString(locale, { weekday: "long" });
      const calender = d.toLocaleDateString("id", {
      day: "numeric",
      month: "long",
      year: "numeric",
      });

const toFirstCase = (str) => {
  let first = str
  .split(" ") // Memenggal nama menggunakan spasi
  .map((nama) => nama.charAt(0).toUpperCase() + nama.slice(1)) // Ganti huruf besar kata-kata pertama
  .join(" ");
  
  return first;
  }
function Ehztext (text, style = 1){
  var abc = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var ehz = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  abc.map((v, i) =>
    replacer.push({
      original: v,
      convert: ehz[style].split('')[i]
    })
  );
  var str = text.split('');
  var output = [];
  str.map((v) => {
    if (v.toUpperCase() !== v.toLowerCase() && v === v.toUpperCase()) {
      // If the character is uppercase, push it unchanged
      output.push(v);
    } else {
      // If the character is lowercase or not a letter, find and convert it
      const find = replacer.find((x) => x.original == v.toLowerCase());
      find ? output.push(find.convert) : output.push(v);
    }
  });
  return output.join('');
};
function makeid(length){
  let result = "";
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};
const sleep = async (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
     
Array.prototype.getRandom = function() {
  return this[Math.floor(Math.random() * this.length)];
};

function getRandom(array) {
  return array.getRandom();
}






function getRandomFile (ext){
  return `${Math.floor(Math.random() * 10000)}${ext}`;
};
const Log = (text) => {
      console.log(text);
      };
async function similarity(one,two) {
const treshold = stringSimilarity.compareTwoStrings(one, two)
return treshold.toFixed(2)
}

global.similarity = (one,two) => similarity(one,two);
global.clockString = clockString;
global.toFirstCase = toFirstCase;
global.getRandomFile = getRandomFile
global.getRandom = getRandom
global.calender = calender;
global.Ehztext = Ehztext;
global.makeid = makeid;
global.calender = calender;
global.sleep = sleep;
global.week = week;
global.Log = Log;

const fs = require("fs");
const { color } = require("./lib/color");
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})






