const fs = require('node:fs');

const config = {
    owner: ["62895323195263"],
    name: "ᴏᴍᴀʀᴜ-ᴘᴏʟᴋᴀ-ʙᴏᴛᴢ",
    ownername: 'ᴡɪʀᴅᴀɴ', 
    ownername2: 'ᴅᴀɴᴢ',
    prefix: [".", "-", "!", "/", "#"], //Tambahin sendiri prefix nya kalo kurang
    wagc: 'https://whatsapp.com/channel/0029VaG9VfPKWEKk1rxTQD20',
    saluran: '120363279195205552@newsletter', 
    jidgroupnotif: '120363266755712733@g.us', 
    saluran2: '120363335701540699@newsletter', 
    jidgroup: '120363267102694949@g.us', 
    jidch: '120363279195205552@newsletter', 
    sessions: "sessions",
    sticker: {
      packname: "〆 ᴏᴍᴀʀᴜ-ᴘᴏʟᴋᴀ-ʙᴏᴛᴢ",
      author: "ʙʏ: ᴅᴀɴᴢ/ᴡɪʀᴅᴀɴ 〆"
    },
   messages: {
      wait: "*( Loading )* Tunggu Sebentar...",
      owner: "*( Denied )* Kamu bukan owner ku !",
      premium: "*( Denied )* Fitur ini khusus user premium",
      group: "*( Denied )* Fitur ini khusus group",
      botAdmin: "*( Denied )* Lu siapa bukan Admin group",
      grootbotbup: "*( Denied )* Jadiin Omaru-Botz admin dulu baru bisa akses",
   },
   database: "hanako-db",
   tz: "Asia/Jakarta"
}

module.exports = config

let file = require.resolve(__filename);
fs.watchFile(file, () => {
   fs.unwatchFile(file);
  delete require.cache[file];
});
