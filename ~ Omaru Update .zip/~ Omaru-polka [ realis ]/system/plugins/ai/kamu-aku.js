//Fitur terkonyol yang gw buat
//danz by like


const fs = require('fs');
const path = './memory.json';

// Cek apakah file memory sudah ada, jika tidak buat file baru
if (!fs.existsSync(path)) {
    fs.writeFileSync(path, JSON.stringify({}, null, 2));
}

// Fungsi untuk membaca dan menyimpan data ingatan
const memory = {
    read: () => JSON.parse(fs.readFileSync(path)),
    write: (data) => fs.writeFileSync(path, JSON.stringify(data, null, 2))
};

module.exports = {
    command: ["ingat", "siapa", "lupakan"],
    alias: [],
    category: ["ai"],
    description: "Fitur AI yang bisa mengingat informasi pengguna",
    loading: false,
    async run(m, { sock, text, command }) {
        let memories = memory.read();
        let sender = m.sender;

        if (command === "ingat") {
            if (!text.includes("saya")) {
                return sock.sendMessage(m.cht, { text: "❌ Format salah! Gunakan: .ingat nama saya Naruto" }, { quoted: m });
            }
            
            let [key, value] = text.replace("saya", "").trim().split(" ");
            if (!key || !value) {
                return sock.sendMessage(m.cht, { text: "❌ Format salah! Contoh: .ingat hobi saya menggambar" }, { quoted: m });
            }

            // Simpan data
            if (!memories[sender]) memories[sender] = {};
            memories[sender][key] = value;
            memory.write(memories);

            return sock.sendMessage(m.cht, { text: `✅ Aku akan mengingat bahwa ${key} kamu adalah ${value}!` }, { quoted: m });
        }

        if (command === "siapa") {
            let key = text.trim();
            if (!memories[sender] || !memories[sender][key]) {
                return sock.sendMessage(m.cht, { text: `🤔 Aku tidak tahu ${key} kamu. Gunakan ".ingat ${key} saya <isi>" untuk menyimpannya!` }, { quoted: m });
            }

            return sock.sendMessage(m.cht, { text: `🧠 Aku ingat! ${key} kamu adalah *${memories[sender][key]}*.` }, { quoted: m });
        }

        if (command === "lupakan") {
            let key = text.trim();
            if (!memories[sender] || !memories[sender][key]) {
                return sock.sendMessage(m.cht, { text: `❌ Aku tidak menyimpan ${key} kamu.` }, { quoted: m });
            }

            delete memories[sender][key];
            memory.write(memories);
            return sock.sendMessage(m.cht, { text: `🗑️ Aku sudah melupakan ${key} kamu.` }, { quoted: m });
        }
    }
};