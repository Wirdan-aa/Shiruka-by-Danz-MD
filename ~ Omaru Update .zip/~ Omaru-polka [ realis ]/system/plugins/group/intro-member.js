module.exports = {
  command: 'intro',
  alias: ['perkenalan', 'aboutme'],
  category: ['group'],
  description: 'Membantu member memperkenalkan diri di grup',

  async run(m, { text }) {
    if (!text) {
      return m.reply(`
╾─────────────────────╼
│ *ᴋᴀʀᴛᴜ ɪɴᴛʀᴏ ᴍᴇᴍʙᴇʀ ᴊᴏᴍᴏᴋ*
│╼ ɴᴀᴍᴀ :
│╼ ᴋᴇʟᴀs :
│╼ ᴜᴍᴜʀ :
│╼ ʜᴏʙʏ :
│╼ ᴀsᴋᴏᴛ :
│╼ ɢᴇɴᴅᴇʀ :
│sᴀʟᴋᴇɴ ᴡᴀᴋ ᴍᴇᴍʙᴇʀ ʙᴀʀᴜ
╾─────────────────────╼
      `);
    }

    // Menampilkan kembali pesan pengguna sebagai perkenalan
    const introMessage = `
🌟 *ᴍᴇᴍᴘᴇʀᴋᴇɴᴀʟᴀɴ ᴍᴇᴍʙᴇʀ* 🌟

${text}

✨ Terima kasih telah memperkenalkan ᴅɪʀ!
    `;

    await m.reply(introMessage);
  },
};