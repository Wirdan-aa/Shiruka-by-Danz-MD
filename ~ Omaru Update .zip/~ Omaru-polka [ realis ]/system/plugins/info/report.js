module.exports = {
    command: "lapor",
    alias: ["report", "bug"],
    category: ["menu"],
    description: "Laporkan bug atau error ke owner",
    async run(m, { sock, text, config }) {
        const ownerNumber = "62895323195263"; // Ganti dengan nomor owner

        // Cek apakah pengguna mengisi laporan
        if (!text) {
            return m.reply(
                "⚠️ *Format salah!*\n\nGunakan:\n.lapor <pesan>\n\nContoh:\n.lapor Bot tidak merespon perintah"
            );
        }

        // Kirim laporan ke owner
        await sock.sendMessage(ownerNumber + "@s.whatsapp.net", {
            text: `📢 *Laporan Baru!*\n\n📌 Dari: @${m.sender.split('@')[0]}\n📝 Pesan: ${text}\n\n⚡ *Segera cek dan tanggapi!*`,
            mentions: [m.sender]
        });

        // Konfirmasi ke pelapor
        m.reply("✅ *Laporan telah dikirim ke owner!*\nTerima kasih telah memberikan feedback.");
    }
};