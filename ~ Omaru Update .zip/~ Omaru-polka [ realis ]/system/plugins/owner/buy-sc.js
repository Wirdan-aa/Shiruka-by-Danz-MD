module.exports = {
    command: "buysc",
    alias: ["belisc"],
    category: ["owner"],
    description: "Kirimkan link script ke nomor pembeli dengan thumbnail dan audio reply.",
    async run(m, { sock, text }) {
        // Periksa apakah format sudah benar
        if (!text) {
            return sock.sendMessage(m.cht, { text: "Format salah! Gunakan: .buysc nomor" }, { quoted: m });
        }

        let nomor = text.trim();

        // Validasi nomor (harus angka dan panjang yang wajar)
        if (!/^\d+$/.test(nomor) || nomor.length < 10 || nomor.length > 15) {
            return sock.sendMessage(m.cht, { text: "Nomor tidak valid! Gunakan angka tanpa spasi atau simbol lainnya." }, { quoted: m });
        }

        // Format nomor agar sesuai dengan WhatsApp (tambahkan @s.whatsapp.net)
        let waNumber = nomor + "@s.whatsapp.net";

        // **🔗 Link Script (MediaFire)**
        const linkSC = "https://www.mediafire.com/file/re3u0az7yb376do/%257E_Hanako-Botz_%255B_Danz_%255D_v1.0.1.zip/file";
        const hargaSC = "Rp15.000"; // Harga yang sudah ditentukan
        const thumbnailUrl = "https://files.catbox.moe/l6ytf9.jpg"; // URL Thumbnail
        const audioUrl = "https://files.catbox.moe/vsxucg.mp4"; // URL Audio

        // **📩 Pesan Sambutan**
        let message = {
            image: { url: thumbnailUrl }, // Kirim gambar dari URL
            caption: `*_Terima kasih telah membeli script ini!_*\n\n` +
                     `*Harga:* ${hargaSC}\n` +
                     `*Link SC:* ${linkSC}\n\n` +
                     `> Pastikan untuk membaca README sebelum menggunakan.\n` +
                     `*Semoga sukses dengan script ini!*`
        };

        try {
            // Kirim pesan dengan gambar ke nomor yang ditentukan
            await sock.sendMessage(waNumber, message);

            // **🔊 Kirim Audio Reply ke Nomor Tujuan**
            await sock.sendMessage(waNumber, {
                audio: { url: audioUrl },
                mimetype: 'audio/mpeg',
                ptt: true
            });

            // **🔊 Kirim Audio Reply ke Pengirim**
            await m.reply({
                audio: { url: audioUrl },
                mimetype: 'audio/mpeg',
                ptt: true
            });

            return sock.sendMessage(m.cht, { text: `Script berhasil dikirim ke ${nomor}.` }, { quoted: m });
        } catch (error) {
            console.error("Error:", error);
            return sock.sendMessage(m.cht, { text: "Terjadi kesalahan! Tidak dapat mengirim script ke nomor tersebut." }, { quoted: m });
        }
    }
};