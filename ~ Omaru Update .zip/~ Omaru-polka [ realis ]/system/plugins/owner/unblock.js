module.exports = {
  command: "unblock",
  alias: ["buka"],
  category: ["owner"],
  settings: {
    owner: true, // Hanya pemilik bot yang dapat menggunakan fitur ini
  },
  description: "Membuka blokir pengguna dengan reply pesan",
  async run(m, { sock }) {
    try {
      // Pastikan ada pesan yang direply
      if (!m.quoted) {
        return m.reply(
          "❌ Harap reply ke pesan pengguna yang ingin dibuka blokirnya.\n\nContoh: Reply ke pesan pengguna dan ketik *unblock*"
        );
      }

      // Ambil ID pengguna dari pesan yang direply
      const user = m.quoted.sender;

      // Memastikan ID pengguna valid
      if (!user || !user.endsWith('@s.whatsapp.net')) {
        return m.reply("❌ ID pengguna tidak valid.");
      }

      // Membuka blokir pengguna
      await sock.updateBlockStatus(user, "unblock");

      // Kirim pesan konfirmasi yang lebih baik
      m.reply(`✅ Pengguna *${user.split("@")[0]}* telah berhasil dibuka blokirnya.\nSekarang mereka dapat mengirim pesan lagi ke grup ini.`);
    } catch (error) {
      console.error(error);
      m.reply("❌ Terjadi kesalahan saat membuka blokir pengguna.\nSilakan coba lagi nanti.");
    }
  },
};