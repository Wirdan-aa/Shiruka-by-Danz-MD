module.exports = {
  command: "listblock",
  alias: ["daftarblokir"],
  category: ["owner"],
  settings: {
    owner: true, // Hanya pemilik bot yang dapat menggunakan fitur ini
  },
  description: "Menampilkan daftar pengguna yang diblokir",
  async run(m, { sock }) {
    try {
      // Ambil daftar blokir dari WhatsApp
      const blocked = await sock.fetchBlocklist();

      if (blocked.length === 0) {
        return m.reply("✅ Tidak ada pengguna yang diblokir.");
      }

      let list = "*Daftar Pengguna yang Diblokir:*\n";
      blocked.forEach((user, index) => {
        list += `\n${index + 1}. ${user.split("@")[0]}`;
      });

      m.reply(list);
    } catch (error) {
      console.error(error);
      m.reply("❌ Terjadi kesalahan saat mengambil daftar blokir.");
    }
  },
};