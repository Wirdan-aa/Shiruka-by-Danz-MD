module.exports = {
  command: "block",
  alias: ["blokir"],
  category: ["owner"],
  settings: {
    owner: true, // Hanya pemilik bot yang dapat menggunakan fitur ini
  },
  description: "Memblokir pengguna berdasarkan pesan mereka",
  async run(m, { sock }) {
    try {
      // Validasi apakah ada pesan yang direply
      if (!m.quoted) {
        return m.reply(
          "❌ Harap reply ke pesan pengguna yang ingin diblokir.\n\nContoh: Reply ke pesan dan ketik *block*"
        );
      }

      // Ambil ID pengguna dari pesan yang direply
      const user = m.quoted.sender;

      // Memblokir pengguna
      await sock.updateBlockStatus(user, "block");
      m.reply(`✅ Pengguna *${user.split("@")[0]}* telah berhasil diblokir.`);
    } catch (error) {
      console.error(error);
      m.reply("❌ Terjadi kesalahan saat memblokir pengguna.");
    }
  },
};