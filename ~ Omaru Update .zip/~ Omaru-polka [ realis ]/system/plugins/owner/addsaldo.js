const fs = require("fs");
const dbFile = "./database.json";

// Nomor Owner (Admin) - hanya owner yang bisa menambah saldo
const ownerNumber = "62895323195263@s.whatsapp.net";

// **1️⃣ Load & Save Database**
const loadDB = () => {
    return fs.existsSync(dbFile) ? JSON.parse(fs.readFileSync(dbFile)) : { users: {} };
};

const saveDB = (db) => {
    fs.writeFileSync(dbFile, JSON.stringify(db, null, 2));
};

// **2️⃣ Fitur Tambah Saldo (Hanya Admin)**
module.exports = {
    command: "addsaldo",
    alias: ["tambahsaldo"],
    category: ["owner"],
    description: "Tambah saldo pengguna (Hanya Owner)",
    async run(m, { sock, text }) {
        // **Cek apakah pengguna adalah admin (owner)**
        if (m.sender !== ownerNumber) {
            return sock.sendMessage(m.cht, { text: "⛔ *Akses Ditolak!*\nHanya owner yang bisa menambah saldo." }, { quoted: m });
        }

        // **Cek format input**
        if (!text.includes("|")) {
            return sock.sendMessage(m.cht, { text: "⚠️ *Format Salah!*\nGunakan: *.addsaldo nomor|jumlah*" }, { quoted: m });
        }

        let [nomor, jumlah] = text.split("|").map((x) => x.trim());

        if (!nomor.startsWith("62")) {
            return sock.sendMessage(m.cht, { text: "⚠️ *Nomor harus menggunakan kode negara (62 untuk Indonesia)*" }, { quoted: m });
        }
        if (isNaN(jumlah) || jumlah <= 0) {
            return sock.sendMessage(m.cht, { text: "⚠️ *Jumlah saldo harus angka positif!*" }, { quoted: m });
        }

        let userId = nomor + "@s.whatsapp.net";
        let db = loadDB();

        // **Tambahkan saldo ke database**
        if (!db.users[userId]) db.users[userId] = 0;
        db.users[userId] += parseInt(jumlah);

        saveDB(db);

        // **Konfirmasi saldo berhasil ditambahkan**
        return sock.sendMessage(m.cht, {
            text: `✅ *Saldo Berhasil Ditambahkan!*\n\n📌 *Nomor:* ${nomor}\n💰 *Jumlah:* ${jumlah} saldo\n🛠 *Total Saldo:* ${db.users[userId]}`
        }, { quoted: m });
    }
};