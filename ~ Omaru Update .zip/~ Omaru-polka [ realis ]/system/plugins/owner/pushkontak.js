module.exports = {
    command: "pushkontak",
    alias: ["broadcast", "bcgroup"],
    category: ["owner"],
    description: "Mengirim pesan ke semua anggota grup dengan jeda.",
    async run(m, { sock, text }) {
        const botNumber = sock.user.id.split(":")[0] + "@s.whatsapp.net"; // Ambil nomor bot

        // Pastikan hanya bot yang bisa menjalankan perintah
        if (m.sender !== botNumber) {
            return sock.sendMessage(m.cht, { text: "❌ *Hanya bot yang bisa menggunakan fitur ini!*" }, { quoted: m });
        }

        // Pastikan fitur dijalankan dalam grup
        if (!m.isGroup) {
            return sock.sendMessage(m.cht, { text: "❌ *Fitur ini hanya bisa digunakan di dalam grup!*" }, { quoted: m });
        }

        // Ambil daftar anggota grup
        const groupMetadata = await sock.groupMetadata(m.cht);
        const participants = groupMetadata.participants.map(p => p.id);

        if (!text) {
            return sock.sendMessage(m.cht, { text: "❌ *Gunakan format:*\n.pushkontak [pesan]" }, { quoted: m });
        }

        // Kirim pesan ke setiap anggota dengan jeda
        for (let i = 0; i < participants.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 10000)); // Jeda 10 detik
            await sock.sendMessage(participants[i], { text: `${text}` });
        }

        return sock.sendMessage(m.cht, { text: "✅ *Pesan berhasil dikirim ke semua anggota grup!*" }, { quoted: m });
    }
};