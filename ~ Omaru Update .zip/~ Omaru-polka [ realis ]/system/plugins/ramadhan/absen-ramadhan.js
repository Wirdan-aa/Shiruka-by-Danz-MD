const fs = require('fs');
const dbFile = './ramadhan.json';

// **Fungsi untuk membaca database**
const loadDatabase = () => {
    return fs.existsSync(dbFile) ? JSON.parse(fs.readFileSync(dbFile)) : {};
};

// **Fungsi untuk menyimpan database**
const saveDatabase = (data) => {
    fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
};

// **Command untuk Absen Ramadhan**
module.exports = {
    command: "absen",
    alias: ["ramadhan"],
    category: ["ramadhan"],
    settings: { limit: true },
    description: "Absen Ramadhan (Subuh, Zuhur, Ashar, Maghrib, Isya, Tarawih)",
    async run(m, { sock, text }) {
        let db = loadDatabase();  // Baca database

        // Periksa format input (contoh: .absen subuh|done)
        if (!text.includes("|")) {
            return sock.sendMessage(m.cht, { text: "*Format Salah!*\nGunakan: .absen subuh|done" }, { quoted: m });
        }

        let [ibadah, status] = text.split("|").map(x => x.trim().toLowerCase());

        // Cek validitas ibadah & status
        let daftarIbadah = ["subuh", "zuhur", "ashar", "maghrib", "isya", "tarawih"];
        if (!daftarIbadah.includes(ibadah) || !["done", "belum"].includes(status)) {
            return sock.sendMessage(m.cht, { text: "*Ibadah atau status tidak valid!*" }, { quoted: m });
        }

        // Ambil tanggal hari ini (format: YYYY-MM-DD)
        let today = new Date().toISOString().split("T")[0];

        // Simpan absen ke database JSON
        let userId = m.sender; // Nomor pengguna
        if (!db[userId]) db[userId] = {}; // Jika belum ada, buat data baru
        if (!db[userId][today]) db[userId][today] = {}; // Buat entri tanggal jika belum ada
        db[userId][today][ibadah] = status; // Simpan absen untuk ibadah hari ini
        saveDatabase(db);

        // Kirim pesan konfirmasi
        let pesan = `✅ *Absen Berhasil!*\n\n📅 *Tanggal:* ${today}\n📌 *Ibadah:* ${ibadah.toUpperCase()}\n📅 *Status:* ${status.toUpperCase()}\n\n🕌 Semoga ibadahmu diterima!`;
        await sock.sendMessage(m.cht, { text: pesan }, { quoted: m });

        // Kirim audio motivasi
        await m.reply({
            audio: { url: "https://files.catbox.moe/w0c4fy.mp4" },
            mimetype: 'audio/mpeg',
            ptt: true
        });
    }
};