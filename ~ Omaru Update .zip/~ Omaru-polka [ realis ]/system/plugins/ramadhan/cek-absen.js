const fs = require('fs');
const dbFile = './ramadhan.json';

// **Fungsi untuk membaca database**
const loadDatabase = () => {
    return fs.existsSync(dbFile) ? JSON.parse(fs.readFileSync(dbFile)) : {};
};

// **Thumbnail URL**
const thumbnailUrl = "https://files.catbox.moe/f987wd.jpg";

// **Command untuk Cek Absen Ramadhan**
module.exports = {
    command: "cekabsen",
    alias: ["rekapabsen"],
    category: ["ramadhan"],
    settings: { limit: true },
    description: "Cek riwayat absen Ramadhan dari awal hingga akhir",
    async run(m, { sock }) {
        let db = loadDatabase(); // Baca database
        let userId = m.sender; // Nomor pengguna

        // Periksa apakah pengguna sudah pernah absen
        if (!db[userId]) {
            return sock.sendMessage(m.cht, { 
                text: "*❌ Kamu belum pernah absen!*",
                contextInfo: {
                    externalAdReply: {
                        title: "Cek Absen Ramadhan",
                        body: "Belum ada data absen yang tercatat.",
                        thumbnailUrl: thumbnailUrl,
                        sourceUrl: thumbnailUrl
                    }
                }
            }, { quoted: m });
        }

        let absenData = db[userId]; // Ambil data absen pengguna
        let daftarTanggal = Object.keys(absenData).sort(); // Urutkan tanggal dari awal ke akhir

        // **Format pesan absen**
        let pesan = `📜 *Riwayat Absen Ramadhan*\n\n`;
        for (let tanggal of daftarTanggal) {
            pesan += `📅 *${tanggal}*\n`;
            let ibadahHarian = absenData[tanggal];
            for (let ibadah in ibadahHarian) {
                let status = ibadahHarian[ibadah] === "done" ? "✅" : "❌";
                pesan += `  - *${ibadah.toUpperCase()}*: ${status}\n`;
            }
            pesan += "\n";
        }

        // **Kirim pesan hasil absen dengan thumbnail**
        await sock.sendMessage(m.cht, { 
            text: pesan.trim(),
            contextInfo: {
                externalAdReply: {
                    title: "Rekap Absen Ramadhan",
                    body: "Berikut adalah riwayat absen kamu.",
                    thumbnailUrl: thumbnailUrl,
                    sourceUrl: thumbnailUrl
                }
            }
        }, { quoted: m });
    }
};