module.exports = {
  command: "puasa",
  alias: ["kapan", "yoramadhan"],
  category: ["ramadhan"],
  description: "Fitur untuk menghitung mundur waktu menuju Ramadhan 2025",
  async run(m, { sock }) {
    try {
      // Tanggal awal Ramadhan 2025 (Perkiraan: 1 Maret 2025)
      const ramadhanDate = new Date("2025-03-01T00:00:00Z"); // Gunakan zona waktu UTC

      // Waktu sekarang
      const now = new Date();

      // Hitung selisih waktu dalam milidetik
      const timeDifference = ramadhanDate - now;

      if (timeDifference <= 0) {
        return sock.sendMessage(m.cht, {
          image: { url: "https://files.catbox.moe/7gwwgl.jpg" }, // Thumbnail
          caption: "> Ramadhan 2025 sudah dimulai! Selamat menjalankan ibadah puasa."
        }, { quoted: m });
      }

      // Konversi ke detik, menit, jam, dan hari
      const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);

      // Kirim pesan hitung mundur dengan thumbnail
      await sock.sendMessage(m.cht, {
        image: { url: "https://files.catbox.moe/7gwwgl.jpg" }, // Thumbnail
        caption: `*Hitung Mundur Menuju Ramadhan 2025*\n` +
                 `📅 *Tanggal:* 1 Maret 2025\n` +
                 `🕒 *Sisa Waktu:*\n` +
                 `➡️ ${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik\n` +
                 `> Semoga kita semua dipertemukan dengan Ramadhan dalam keadaan sehat.`
      }, { quoted: m });

      // Kirim audio motivasi setelah hitung mundur
      await m.reply({
        audio: { url: "https://file.btch.rf.gd/file/7e3125j2l666t5zgbqn1.mp3" },
        mimetype: 'audio/mpeg',
        ptt: true
      });

    } catch (error) {
      console.error(error);
      sock.sendMessage(m.cht, { text: "❌ Terjadi kesalahan saat memproses permintaan." }, { quoted: m });
    }
  },
};