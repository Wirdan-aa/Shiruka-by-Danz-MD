const fetch = require("node-fetch");

const domain = "https//com"; // Ganti dengan domain Pterodactyl Panel
const plta_apikey = "pLta"; // API Key PLTA
const pltc_apikey = "pLtc"; // API Key PLTC

module.exports = {
    command: "delserver",
    alias: ["deleteserver", "hapusserver"],
    category: ["admin"],
    settings: { limit: true },
    description: "Menghapus semua server & user dari Pterodactyl berdasarkan username",
    async run(m, { sock, text }) {
        if (!text) {
            return sock.sendMessage(m.cht, {
                text: "*Gunakan format:*\n.delserver username",
            }, { quoted: m });
        }

        let username = text.toLowerCase();

        try {
            // **1️⃣ Ambil data user berdasarkan username**
            let userResponse = await fetch(`${domain}/api/application/users?filter[username]=${username}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    Authorization: `Bearer ${plta_apikey}`,
                },
            });

            let userData = await userResponse.json();
            if (!userData.data || userData.data.length === 0) {
                return sock.sendMessage(m.cht, {
                    text: `❌ *User tidak ditemukan!*\nUsername: ${username}`,
                }, { quoted: m });
            }

            let user = userData.data[0].attributes;
            let userId = user.id;

            // **2️⃣ Ambil semua server milik user**
            let serverResponse = await fetch(`${domain}/api/application/servers?filter[user_id]=${userId}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    Authorization: `Bearer ${plta_apikey}`,
                },
            });

            let serverData = await serverResponse.json();
            let serverList = serverData.data;

            // **3️⃣ Hapus semua server milik user**
            let deletedServers = 0;
            for (let server of serverList) {
                let serverId = server.attributes.id;

                let deleteServerResponse = await fetch(`${domain}/api/application/servers/${serverId}`, {
                    method: "DELETE",
                    headers: {
                        Accept: "application/json",
                        Authorization: `Bearer ${plta_apikey}`,
                    },
                });

                if (deleteServerResponse.status === 204) {
                    deletedServers++;
                }
            }

            // **4️⃣ Hapus user dari Pterodactyl**
            let deleteUser = await fetch(`${domain}/api/application/users/${userId}`, {
                method: "DELETE",
                headers: {
                    Accept: "application/json",
                    Authorization: `Bearer ${pltc_apikey}`,
                },
            });

            if (deleteUser.status !== 204) {
                return sock.sendMessage(m.cht, {
                    text: `⚠️ *Semua server dihapus, tapi user masih ada!*\n👤 Username: ${username}`,
                }, { quoted: m });
            }

            // **5️⃣ Kirim konfirmasi ke pengguna**
            let message = `✅ *Semua Server & User Berhasil Dihapus!*\n\n👤 *Username:* ${username}\n🖥️ *Jumlah Server Dihapus:* ${deletedServers}`;
            await sock.sendMessage(m.cht, { text: message }, { quoted: m });

        } catch (error) {
            console.error("Error:", error);
            return sock.sendMessage(m.cht, {
                text: `🚨 *Terjadi Kesalahan!*\n${error.message}`,
            }, { quoted: m });
        }
    },
};