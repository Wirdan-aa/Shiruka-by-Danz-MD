const fetch = require('node-fetch');
const crypto = require('crypto');

const domain = "https//com"; // Ganti dengan domain Pterodactyl Panel
const plta_apikey = "ptla"; // Ganti dengan API Key PLTA
const pltc_apikey = "ptlc"; // Ganti dengan API Key PLTC

module.exports = {
    command: "cadmin",
    alias: ["createadmin"],
    category: ["panel"],
    settings: { limit: true },
    description: "Buat akun admin di Pterodactyl Panel menggunakan PLTA & PLTC API Key",
    async run(m, { sock, text }) {
        if (!text) 
            return sock.sendMessage(m.cht, { text: "*Gunakan format:*\n.cadmin username" }, { quoted: m });

        let username = text.toLowerCase();
        let email = `${username}@gmail.com`;
        let password = username + crypto.randomBytes(2).toString('hex');
        let name = username.charAt(0).toUpperCase() + username.slice(1);

        try {
            let response = await fetch(`${domain}/api/application/users`, {
                method: "POST",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${plta_apikey}` // Menggunakan PLTA API Key
                },
                body: JSON.stringify({
                    email: email,
                    username: username,
                    first_name: name,
                    last_name: "Admin",
                    root_admin: true,
                    language: "en",
                    password: password
                })
            });

            let data = await response.json();
            if (data.errors) 
                return sock.sendMessage(m.cht, { text: `❌ *Gagal Membuat Akun!*\n\n${JSON.stringify(data.errors[0], null, 2)}` }, { quoted: m });

            let user = data.attributes;
            let pesan = `
✅ *Admin Panel Berhasil Dibuat!*

👤 *ID User:* ${user.id}
📛 *Nama:* ${user.first_name}
🔑 *Username:* ${user.username}
🔒 *Password:* ${password}
🌐 *Login:* ${domain}

⚠️ *Rules Admin Panel:*
- Jangan bagikan akun ini sembarangan.
- Gunakan hanya untuk keperluan administrasi.
- Simpan informasi ini dengan baik.
            `;

            await sock.sendMessage(m.cht, { text: pesan }, { quoted: m });

            // Tambahkan PLTC API Key untuk operasi lain (contoh: update role admin)
            let updateResponse = await fetch(`${domain}/api/application/users/${user.id}`, {
                method: "PATCH",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${pltc_apikey}` // Menggunakan PLTC API Key
                },
                body: JSON.stringify({
                    root_admin: true
                })
            });

            let updateData = await updateResponse.json();
            if (updateData.errors) 
                return sock.sendMessage(m.cht, { text: `⚠️ *Akun dibuat, tetapi gagal mengupdate role admin!*\n\n${JSON.stringify(updateData.errors[0], null, 2)}` }, { quoted: m });

        } catch (error) {
            console.error("Error creating admin:", error);
            return sock.sendMessage(m.cht, { text: "🚨 *Terjadi Kesalahan!*\nTidak dapat membuat akun admin." }, { quoted: m });
        }
    }
};