const fs = require("fs");
const fetch = require("node-fetch");
const crypto = require("crypto");

const dbFile = "./database.json"; // 🔥 Path database
const domain = "https://com"; // Ganti dengan domain Pterodactyl Panel
const apikey = "pLta"; // PTLA API Key
const capikey = "pLtc"; // PTLC API Key
const egg = "15"; // Egg ID
const nestid = "5"; // Nest ID
const loc = "1"; // Location ID
const dockerImage = "ghcr.io/parkervcp/yolks:nodejs_18";
const startupCommand = "node server.js";

// **1️⃣ Fungsi Load & Save Database**
const loadDatabase = () => {
    try {
        if (!fs.existsSync(dbFile)) {
            fs.writeFileSync(dbFile, JSON.stringify({ users: {} }, null, 2));
        }
        return JSON.parse(fs.readFileSync(dbFile, "utf8"));
    } catch (error) {
        console.error("⚠️ ERROR: Gagal membaca database!", error);
        return { users: {} };
    }
};

const saveDatabase = (db) => {
    try {
        fs.writeFileSync(dbFile, JSON.stringify(db, null, 2));
    } catch (error) {
        console.error("⚠️ ERROR: Gagal menyimpan database!", error);
    }
};

// **2️⃣ Perintah CPanel**
module.exports = {
    command: "cpanel",
    alias: ["createserver"],
    category: ["panel"],
    settings: { limit: true },
    description: "Buat akun dan server Pterodactyl dengan saldo.",
    async run(m, { sock, text }) {
        if (!text.includes("|") || !text.includes(",")) {
            return sock.sendMessage(m.cht, {
                text: "❌ *Format Salah!*\nGunakan: #cpanel 1gb|username,nomor",
            }, { quoted: m });
        }

        let [size, userData] = text.split("|").map((x) => x.trim());
        let [username, phoneNumber] = userData.split(",").map((x) => x.trim());

        let sizes = {
            "1gb": 1000,
            "2gb": 2000,
            "3gb": 3000,
            "4gb": 4000,
            "5gb": 5000,
            "6gb": 6000,
            "7gb": 7000,
            "8gb": 8000,
            "9gb": 9000,
            "10gb": 10000,
        };

        if (!sizes[size]) {
            return sock.sendMessage(m.cht, {
                text: "❌ *Kapasitas tidak valid!*\nGunakan: #cpanel 1gb sampai #10gb",
            }, { quoted: m });
        }

        let email = `${username}@gmail.com`;
        let password = username + crypto.randomBytes(2).toString("hex");

        // **3️⃣ Cek & Update Saldo Pengguna**
        let db = loadDatabase();
        let userNumber = m.sender; // Format WhatsApp ID

        if (!db.users[userNumber]) {
            db.users[userNumber] = 0; // Inisialisasi saldo 0 jika belum ada
            saveDatabase(db);
        }

        let userSaldo = db.users[userNumber];
        let harga = sizes[size];

        if (userSaldo < harga) {
            return sock.sendMessage(m.cht, {
                text: `❌ *Saldo Tidak Cukup!*\n\n💰 Saldo Anda: ${userSaldo} 💰\n💵 Harga: ${harga} 💰`,
            }, { quoted: m });
        }

        // **4️⃣ Kurangi Saldo & Simpan**
        db.users[userNumber] -= harga;
        saveDatabase(db);

        try {
            // **5️⃣ Cek apakah user sudah ada**
            let userCheck = await fetch(`${domain}/api/application/users?filter[email]=${email}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apikey}`,
                },
            });

            let userData = await userCheck.json();
            let userId;

            if (userData.data.length > 0) {
                userId = userData.data[0].attributes.id;
            } else {
                // **6️⃣ Buat user baru jika belum ada**
                let userCreate = await fetch(`${domain}/api/application/users`, {
                    method: "POST",
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${apikey}`,
                    },
                    body: JSON.stringify({
                        email: email,
                        username: username,
                        first_name: username,
                        last_name: "User",
                        language: "en",
                        root_admin: false,
                        password: password,
                    }),
                });

                let userResponse = await userCreate.json();
                if (userResponse.errors) {
                    return sock.sendMessage(m.cht, {
                        text: `❌ *Gagal Membuat User!*\n\n${JSON.stringify(userResponse.errors[0], null, 2)}`,
                    }, { quoted: m });
                }

                userId = userResponse.attributes.id;
            }

            // **7️⃣ Buat Server Baru**
            let serverName = `Server-${username}`;
            let serverCreate = await fetch(`${domain}/api/application/servers`, {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apikey}`,
                },
                body: JSON.stringify({
                    name: serverName,
                    user: userId,
                    egg: egg,
                    docker_image: dockerImage,
                    startup: startupCommand,
                    environment: {
                        CMD_RUN: "npm start",
                    },
                    limits: {
                        memory: sizes[size],
                        swap: 0,
                        disk: 5000,
                        io: 500,
                        cpu: 100,
                    },
                    feature_limits: {
                        databases: 1,
                        backups: 1,
                        allocations: 1,
                    },
                    deploy: {
                        locations: [loc],
                        dedicated_ip: false,
                        port_range: [],
                    },
                }),
            });

            let serverResponse = await serverCreate.json();
            if (serverResponse.errors) {
                return sock.sendMessage(m.cht, {
                    text: `❌ *Gagal Membuat Server!*\n\n${JSON.stringify(serverResponse.errors[0], null, 2)}`,
                }, { quoted: m });
            }

            let serverId = serverResponse.attributes.id;
            let panelUrl = `${domain}/server/${serverId}`;

            // **8️⃣ Kirim Data ke Nomor Pribadi**
            let message = `
✅ *Akun & Server Berhasil Dibuat!*

👤 *Username:* ${username}
📧 *Email:* ${email}
🔑 *Password:* ${password}
💾 *RAM:* ${size.toUpperCase()}
🔗 *Panel:* ${panelUrl}

💰 *Saldo Tersisa:* ${db.users[userNumber]} 💰

⚠️ *Simpan baik-baik data ini!*`;

            await sock.sendMessage(phoneNumber + "@s.whatsapp.net", { text: message });

            // **9️⃣ Konfirmasi ke pengguna**
            return sock.sendMessage(m.cht, {
                text: `✅ *Server & Akun berhasil dibuat!*\n\n📩 *Data telah dikirim ke nomor ${phoneNumber}*\n💰 *Saldo Tersisa:* ${db.users[userNumber]} 💰`,
            }, { quoted: m });

        } catch (error) {
            console.error("Error:", error);
            return sock.sendMessage(m.cht, {
                text: "🚨 *Terjadi Kesalahan!*\nTidak dapat membuat akun atau server.",
            }, { quoted: m });
        }
    },
};