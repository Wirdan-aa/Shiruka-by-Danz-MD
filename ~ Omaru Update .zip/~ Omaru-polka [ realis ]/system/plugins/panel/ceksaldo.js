const fs = require("fs");
const dbFile = "./database.json";

// Fungsi untuk membaca database saldo
const loadDB = () => {
    try {
        if (!fs.existsSync(dbFile)) {
            fs.writeFileSync(dbFile, JSON.stringify({ users: {} }, null, 2));
        }
        return JSON.parse(fs.readFileSync(dbFile));
    } catch (err) {
        console.error("Error membaca database:", err);
        return { users: {} };
    }
};

module.exports = {
    command: "ceksaldo",
    alias: ["saldouser"],
    category: ["tools"],
    description: "Cek saldo pribadi atau pengguna lain",
    async run(m, { sock, text }) {
        try {
            let db = loadDB();
            let senderNumber = m.sender.replace("@s.whatsapp.net", ""); // Nomor pengirim
            let targetNumber = text ? text.trim() : senderNumber; // Jika tidak ada teks, cek saldo sendiri
            let targetUser = targetNumber + "@s.whatsapp.net"; // Format nomor target

            // Ambil saldo dari database
            let saldo = db.users[targetUser] || 0; // Jika tidak ada data, saldo default 0

            return sock.sendMessage(m.cht, {
                text: `💰 *Saldo Pengguna*\n\n📌 *Nomor:* ${targetNumber}\n💵 *Saldo:* ${saldo} saldo`
            }, { quoted: m });

        } catch (error) {
            console.error("Error pada fitur ceksaldo:", error);
            return m.reply(
                "*– 乂 *Error Terdeteksi* 📉*\n\n> Command gagal dijalankan karena terjadi error\n> Laporan telah dikirim kepada owner kami dan akan segera diperbaiki!"
            );
        }
    }
};