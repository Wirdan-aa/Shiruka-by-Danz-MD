const fetch = require("node-fetch");
const crypto = require("crypto");

const domain = "https//com"; // Ganti dengan domain Pterodactyl Panel
const plta_apikey = "ptla"; // PLTA API Key
const pltc_apikey = "ptlc"; // PLTC API Key
const egg = "15"; // Egg ID (Pastikan benar)
const nestid = "5"; // Nest ID
const loc = "1"; // Location ID
const dockerImage = "ghcr.io/parkervcp/yolks:nodejs_18"; // Sesuaikan dengan Egg
const startupCommand = "node server.js"; // Sesuaikan dengan kebutuhan

module.exports = {
  command: "cadmin-v2",
  alias: ["createadmin-v2"],
  category: ["panel"],
  settings: { limit: true },
  description: "Buat akun admin di Pterodactyl Panel & otomatis buat server",
  async run(m, { sock, text }) {
    if (!text) {
      return sock.sendMessage(m.cht, {
        text: "*Gunakan format:*\n.cadmin username",
      }, { quoted: m });
    }

    let username = text.toLowerCase();
    let email = `${username}@gmail.com`;
    let password = username + crypto.randomBytes(2).toString("hex");
    let name = username.charAt(0).toUpperCase() + username.slice(1);

    try {
      // **1️⃣ Buat akun admin**
      let response = await fetch(`${domain}/api/application/users`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta_apikey}`,
        },
        body: JSON.stringify({
          email: email,
          username: username,
          first_name: name,
          last_name: "Admin",
          root_admin: true,
          language: "en",
          password: password,
        }),
      });

      let data = await response.json();
      if (data.errors) {
        return sock.sendMessage(m.cht, {
          text: `❌ *Gagal Membuat Akun Admin!*\n\n${JSON.stringify(data.errors[0], null, 2)}`,
        }, { quoted: m });
      }

      let user = data.attributes;

      // **2️⃣ Buat server untuk admin**
      let serverName = `Admin-${username}`;
      let serverCreate = await fetch(`${domain}/api/application/servers`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta_apikey}`,
        },
        body: JSON.stringify({
          name: serverName,
          user: user.id,
          egg: egg,
          docker_image: dockerImage,
          startup: startupCommand,
          environment: {
            CMD_RUN: "npm start",
          },
          limits: {
            memory: 2000, // 2GB RAM untuk admin
            swap: 0,
            disk: 5000, // 5GB storage
            io: 500,
            cpu: 100,
          },
          feature_limits: {
            databases: 2,
            backups: 2,
            allocations: 1,
          },
          deploy: {
            locations: [loc],
            dedicated_ip: false,
            port_range: [],
          },
        }),
      });

      let serverResponse = await serverCreate.json();
      if (serverResponse.errors) {
        return sock.sendMessage(m.cht, {
          text: `❌ *Gagal Membuat Server untuk Admin!*\n\n${JSON.stringify(serverResponse.errors[0], null, 2)}`,
        }, { quoted: m });
      }

      let serverId = serverResponse.attributes.id;
      let panelUrl = `${domain}/server/${serverId}`;

      // **3️⃣ Kirim konfirmasi ke pengguna**
      let message = `
✅ *Admin Panel & Server Berhasil Dibuat!*

👤 *ID User:* ${user.id}
📛 *Nama:* ${user.first_name}
🔑 *Username:* ${user.username}
🔒 *Password:* ${password}
🌐 *Login Panel:* ${domain}
🖥️ *Server Admin:* ${panelUrl}

⚠️ *Simpan informasi ini dengan baik!*`;

      await sock.sendMessage(m.cht, { text: message }, { quoted: m });

    } catch (error) {
      console.error("Error:", error);
      return sock.sendMessage(m.cht, {
        text: "🚨 *Terjadi Kesalahan!*\nTidak dapat membuat akun admin & server.",
      }, { quoted: m });
    }
  },
};