module.exports = {
  command: "listpanel",
  alias: ["harga", "pricelist"],
  category: ["info"],
  description: "Menampilkan daftar harga & RAM server Pterodactyl",
  async run(m) {
    const priceList = `
 *Daftar Harga & RAM Panel Pterodactyl by Danz* 

∘ 1GB    ➝ 1.000 saldo
∘ 2GB    ➝ 2.000 saldo
∘ 3GB    ➝ 3.000 saldo
∘ 4GB    ➝ 4.000 saldo
∘ 5GB    ➝ 5.000 saldo
∘ 6GB    ➝ 6.000 saldo
∘ 7GB    ➝ 7.000 saldo
∘ 8GB    ➝ 8.000 saldo
∘ 9GB    ➝ 9.000 saldo
∘ 10GB   ➝ 10.000 saldo

    `;

    m.reply(priceList);
  },
};