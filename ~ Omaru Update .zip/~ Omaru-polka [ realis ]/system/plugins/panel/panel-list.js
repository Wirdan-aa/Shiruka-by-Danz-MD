const fetch = require("node-fetch");

const domain = "https//com"; // Ganti dengan domain Pterodactyl Panel
const plta_apikey = "pLta"; // API Key PLTA
const pltc_apikey = "pLtc"; // API Key PLTC

module.exports = {
    command: "listserver",
    alias: ["servers", "srvlist"],
    category: ["admin"],
    settings: { limit: true },
    description: "Melihat semua server yang terdaftar di Pterodactyl",
    async run(m, { sock }) {
        try {
            let serverList = [];
            let page = 1;
            let totalPages = 1;

            // **1️⃣ Mengambil semua server dari API PLTA**
            while (page <= totalPages) {
                let response = await fetch(`${domain}/api/application/servers?page=${page}`, {
                    method: "GET",
                    headers: {
                        Accept: "application/json",
                        Authorization: `Bearer ${plta_apikey}`,
                    },
                });

                let data = await response.json();
                if (data.errors) {
                    return sock.sendMessage(m.cht, {
                        text: `🚨 *Gagal mengambil daftar server!*\n\n${JSON.stringify(data.errors[0], null, 2)}`,
                    }, { quoted: m });
                }

                totalPages = data.meta.pagination.total_pages; // Jumlah halaman total
                serverList = serverList.concat(data.data); // Gabungkan semua data server
                page++;
            }

            if (serverList.length === 0) {
                return sock.sendMessage(m.cht, { text: "⚠️ *Tidak ada server terdaftar!*" }, { quoted: m });
            }

            // **2️⃣ Cek status server satu per satu menggunakan API PLTC**
            let serverStatusPromises = serverList.map(async (server) => {
                try {
                    let statusResponse = await fetch(`${domain}/api/client/servers/${server.attributes.identifier}/resources`, {
                        method: "GET",
                        headers: {
                            Accept: "application/json",
                            Authorization: `Bearer ${pltc_apikey}`,
                        },
                    });

                    let statusData = await statusResponse.json();
                    if (statusData.attributes) {
                        return {
                            id: server.attributes.id,
                            name: server.attributes.name,
                            owner: server.attributes.user,
                            status: statusData.attributes.current_state === "running" ? "🟢 Online" : "🔴 Offline",
                        };
                    } else {
                        return {
                            id: server.attributes.id,
                            name: server.attributes.name,
                            owner: server.attributes.user,
                            status: "❓ Tidak diketahui",
                        };
                    }
                } catch (error) {
                    return {
                        id: server.attributes.id,
                        name: server.attributes.name,
                        owner: server.attributes.user,
                        status: "❓ Tidak dapat mengambil status",
                    };
                }
            });

            let serversWithStatus = await Promise.all(serverStatusPromises);

            // **3️⃣ Format daftar server untuk ditampilkan**
            let message = `📋 *Daftar Semua Server:*\n\n`;
            serversWithStatus.forEach((srv) => {
                message += `username = *${srv.name}*\n id: ${srv.owner}\n\n`;
            });

            await sock.sendMessage(m.cht, { text: message }, { quoted: m });

        } catch (error) {
            console.error("Error:", error);
            return sock.sendMessage(m.cht, {
                text: "🚨 *Terjadi Kesalahan!*\nTidak dapat mengambil daftar server.",
            }, { quoted: m });
        }
    },
};